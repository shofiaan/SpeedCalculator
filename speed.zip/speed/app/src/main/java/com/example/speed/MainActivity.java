package com.example.speed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    private Button dstbtn;
    private Button taimbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        hitung();

        dstbtn = (Button) findViewById(R.id.btndst);
        dstbtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick (View v){
            opendst();
        }
    });
        taimbtn = (Button) findViewById(R.id.btntime);
        taimbtn.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick (View v){
            opentaim();
        }
    });


    }
    public void opendst(){
        Intent intent = new Intent(this, MainActivity2.class);
        startActivity(intent);
    }
    public void opentaim(){
        Intent intent1 = new Intent(this, MainActivity3.class);
        startActivity(intent1);
    }


    public void hitung() {
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText dstText = (EditText) findViewById(R.id.dst);
                String dstStr = dstText.getText().toString();
                double dist = Double.parseDouble(dstStr);

                final EditText timeText = (EditText) findViewById(R.id.tm);
                String timeStr = timeText.getText().toString();
                double timee = Double.parseDouble(timeStr);

                double spd = (dist) / (timee);
                DecimalFormat df = new DecimalFormat("#.#");
                double speed = Double.parseDouble(df.format(spd));
                final EditText rsp = (EditText) findViewById(R.id.sp);
                rsp.setText(Double.toString(speed));
            }
        });
    }
}