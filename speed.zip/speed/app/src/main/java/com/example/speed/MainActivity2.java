package com.example.speed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {
    private Button tmbtn;
    private Button spdbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        hitung();

        tmbtn = (Button) findViewById(R.id.btntm2);
        tmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                opentm();
            }
        });

        spdbtn = (Button) findViewById(R.id.btnsp2);
        spdbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                opensp();
            }
        });
    }

    public void opentm(){
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }
    public void opensp(){
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
    public void hitung() {
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText spdText = (EditText) findViewById(R.id.spd3);
                String spdStr = spdText.getText().toString();
                double speed = Double.parseDouble(spdStr);

                final EditText timeText = (EditText) findViewById(R.id.taim);
                String timeStr = timeText.getText().toString();
                double timee = Double.parseDouble(timeStr);

                double dist = (speed) * (timee);
                DecimalFormat df = new DecimalFormat("#.#");
                double distance = Double.parseDouble(df.format(dist));
                final EditText rsp = (EditText) findViewById(R.id.dst);
                rsp.setText(Double.toString(distance));
            }
        });
    }
}