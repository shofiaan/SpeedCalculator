package com.example.speed;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity3 extends AppCompatActivity {
    private Button speedbut;
    private Button distbut;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        hitung();
        speedbut = (Button) findViewById(R.id.btnspeed);
        speedbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                openspeed();
            }
        });
        distbut = (Button) findViewById(R.id.btndistance);
        distbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick (View v){
                opendistance();
            }
        });
    }
    public void openspeed(){
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
    public void opendistance(){
        Intent intent2 = new Intent(this, MainActivity2.class);
        startActivity(intent2);
    }
        public void hitung() {
            Button button = (Button)findViewById(R.id.btnresult);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final EditText spdText = (EditText) findViewById(R.id.speed);
                    String spdStr = spdText.getText().toString();
                    double speed = Double.parseDouble(spdStr);

                    final EditText disText = (EditText) findViewById(R.id.distance);
                    String disStr = disText.getText().toString();
                    double distancee = Double.parseDouble(disStr);

                    double waktu = (distancee) / (speed);
                    DecimalFormat df = new DecimalFormat("#.#");
                    double wkt = Double.parseDouble(df.format(waktu));
                    final EditText rst = (EditText) findViewById(R.id.timeres);
                    rst.setText(Double.toString(waktu));
                }
            });
        }
    }